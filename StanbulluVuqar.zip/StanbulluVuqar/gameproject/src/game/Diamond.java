
package game;


import java.awt.Graphics;
import java.awt.image.BufferedImage;

 class Diamond extends GameObject{

    static BufferedImage image;

    public Diamond(int x, int y, ID id) {
        super(x, y+25, id,40,40); 
        if(image == null){
            image = ImageLoader.loadImage("res/brilliant.png", this);
        }
    }

    @Override
    public void tick() {
    
    }

    @Override
    public void render(Graphics g) {
         g.drawImage(image, x, y, width, height, null);
    }
    
}

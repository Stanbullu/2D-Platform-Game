
package game;


public enum ID {
    Player,Enemy,Platform,Camera,BoxCollision,Fire,Trigger,LevelDoor,Crystal,Bullet,MovingPlatform;
}

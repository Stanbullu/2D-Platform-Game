

package game;

import java.awt.Graphics;
import java.awt.image.BufferedImage;


public class Crystal extends GameObject{
    static BufferedImage image;
    
    public Crystal(int x, int y, ID id) {
        super(x, y-10, id, 50, 50);
        if(image == null){
            image = ImageLoader.loadImage("res/crystal.png", this);
        }
    }

    @Override
    public void tick() {

    }

    @Override
    public void render(Graphics g) {
        g.drawImage(image, x, y,width,height, null);
    }
    
}

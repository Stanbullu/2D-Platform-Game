
package game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;


public class BoxCollision extends GameObject {
    boolean trigged = false;
    static BufferedImage image;
    public BoxCollision(int x, int y, ID id) {
        super(x, y, id);
        width = 20;
        height = 20;
        if(image == null){
            image = ImageLoader.loadImage("res/Bush.png", this);
        }
    }

    @Override
    public void tick() {
        if(Game.player.getBounds().intersects(this.getBounds())){
            trigged = true;
        }else{
            trigged = false;
        }
    }

    @Override
    public void render(Graphics g) {
        g.drawImage(image, x, y,width, height, null);
    }

    public boolean isTrigged() {
        return trigged;
    }
    
}



package game;

import java.awt.Color;
import java.awt.Graphics;


public class Camera extends GameObject {
    public float cameraSpeed = 0.05f;
    public Camera(int x, int y, ID id) {
        super(x, y, id);
        this.width = 500;
        this.height = 500;
    }

    @Override
    public void tick() {
        x += ((Game.player.getX()+Game.player.getBounds().width-x)-Game.WIDTH/2)*cameraSpeed;
        y += ((Game.player.getY()+Game.player.getBounds().height-y)-Game.HEIGHT/2)*cameraSpeed;
      
    }

    @Override
    public void render(Graphics g) {

    }
    
}

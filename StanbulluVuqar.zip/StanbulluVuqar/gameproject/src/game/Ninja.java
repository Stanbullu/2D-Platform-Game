
package game;

import static game.GameObject.BoundsType.DownBound;
import static game.GameObject.BoundsType.LeftBound;
import static game.GameObject.BoundsType.PlatformTrackerBound;
import static game.GameObject.BoundsType.RightBound;
import static game.GameObject.BoundsType.UpBound;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;


public class Ninja extends GameObject {
    
    boolean intersects = false;
    boolean onPlatform = false;
    int dist;
    int direction = 1;
    
    static BufferedImage run[] = new BufferedImage[10];
    static BufferedImage idle[] = new BufferedImage[10];

    private final Animation ninjaIdle;
    
    private int index = 0;
    
    public Ninja(int x, int y, ID id) {
        super(x, y, id, 60, 85);
        
        
        velX = 0;
        if(idle[0] == null){
            for(int i=0; i<10; i++){
                idle[i] = ImageLoader.loadImage("res/Idle_"+i+".png", this);
            }
        }
        ninjaIdle = new Animation(3, run);

        if(run[0] == null){
            for(int i=0; i<10; i++){
                run[i] = ImageLoader.loadImage("res/Run_"+i+".png", this);
            }
        }
        
    }

    @Override
    public void tick() { 
         ninjaIdle.runAnimation();
        
        if(!onPlatform) {
            velY += GameSpace.gravity;
        }
        
        y += velY;
        
        
        int player_x = Game.player.x;
        dist = Math.abs(player_x-x);
        if(dist < 350){
            velX = 1;
            if(x + width<= player_x) {
                Shot(40, "right");                
                x += this.velX;
                direction = 0;
            }else if(this.x >= player_x+Game.player.width) {
                Shot(40, "left");                
                x -= this.velX;
                direction = 1;
            }
        }else
            velX = 0;
        
        
        Collision();
    }
     public void Shot(int speed, String position){
        index++;
        if(index > speed){
            index = 0;
            Game.handler.addObject(new Kunai(x, (int) (y+width/4.5), ID.Bullet, position));
        }
    }
    public void Collision() {
        intersects = false;
        onPlatform = false;
        for(int i = 0; i< Game.handler.object.size(); i++){
            GameObject obj = Game.handler.object.get(i);
            if( obj != this)
                if(obj.getId() == ID.Fire){
                    if(obj.getBounds().intersects(this.getBounds())){
                        Game.handler.removeObject(this);
                    }
                }
                if(obj.getId() == ID.Platform){
                    if(obj.getBounds().intersects(this.getBounds())){
                        if(obj.getBounds(DownBound).intersects(this.getBounds(UpBound))){
                            velY *=-1;
                            y = obj.getY()+obj.height + height;
                        }else if(obj.getBounds(LeftBound).intersects(this.getBounds(RightBound))){
                            velX *= -1;
                            x = obj.getX() - width;
                        }else if(obj.getBounds(RightBound).intersects(this.getBounds(LeftBound))){
                            velX *= -1;
                            x = obj.getX() + obj.width;
                        }else if(obj.getBounds(UpBound).intersects(this.getBounds(DownBound))){
                            velY = 0;
                            y = obj.getY()- height;
                        }
                    }
                    if(obj.getBounds().intersects(this.getBounds(PlatformTrackerBound))){
                        onPlatform = true;
                    }
                }
        }
    }
    
    @Override
    public void render(Graphics g) {

      if(velX == 0){
            if(direction == 0)
                ninjaIdle.drawAnimation(g, x, y, width, height);
            else
                ninjaIdle.drawAnimation(g, x+width, y, -width, height);
        }else{
            int ind = Math.abs(((int)x/10)%7+1);
            if(direction == 0)
                g.drawImage(run[ind], x, y, width, height, null);
            else
                g.drawImage(run[ind], x+width, y, -width, height, null);
        }
    }
}


package game;

import java.awt.Graphics;
import java.awt.image.BufferedImage;


public class Bird extends GameObject {
    static BufferedImage image[] = new BufferedImage[4];
    
    public Bird(int x, int y, ID id) {
        super(x, y, id);
        velX = 2;
        velY = 3;
        if(image[0] == null){
            for(int i=0; i<4; i++){
                image[i] = ImageLoader.loadImage("res/bird"+i+".png", this);
            }
        }
    }

    @Override
    public void tick() {
        y += velY;
        if(y > Game.HEIGHT-height || y<0) velY *= -1;
        
    }

    @Override
    public void render(Graphics g) {
        int ind = Math.abs(((int)y/15)%4);
        g.drawImage(image[ind], x, y, width, height, null);
    }
    
}

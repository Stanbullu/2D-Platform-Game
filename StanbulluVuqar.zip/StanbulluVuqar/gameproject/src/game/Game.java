package game;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Game extends Canvas implements Runnable {

    public static final int WIDTH = 1000, HEIGHT = WIDTH / 2;

    private Window gameWindow;
    private Thread thread;
    private boolean running = false;
    private Random rand;
    public static Handler handler;
    public HUD hud;
    public static Player player;
    public static boolean gameRun = true;
    public static Camera camera;
    public static int time = 0;
    public static boolean isCoin = false;
    
    
    
    private BufferedImage bg1;
    

    private enum STATE {

        MENU,
        GAME,
        HELP,
        OPTIONS;
    };
    private STATE gameState = STATE.GAME;

    public Game() {
        rand = new Random();
        handler = new Handler();
        player = new Player(340, 70, ID.Player);
        camera = new Camera(0, 0, ID.Camera);

        this.addKeyListener(new KeyInput(this, player));

        gameWindow = new Window(WIDTH, HEIGHT, "With LinkedList", this);
        
        handler.addObject(player); 
        handler.addObject(camera);
        
        
        hud = new HUD();
        loadLevel(1);
        bg1 = ImageLoader.loadImage("res/bck1.png", this);
        

        
        handler.addObject(player);
        
        if (gameState == STATE.GAME) {

        }
        GameSpace.gameInstance = this;
    }
    public void loadLevel(int i){
        handler.object.clear();

        handler.addObject(player);
        handler.addObject(camera);
        switch(i){
            
            case 1: player.setX(100); 
            ImageLoader.loadFileLevel("res/level.png", this, handler, player); 
            break;
            
            
        } 
        
       
    }
    public static void main(String[] args) {
        new Game();
    }

    public synchronized void start() {
        thread = new Thread(this);
        thread.start();
        running = true;
    }

    public synchronized void stop() {
        try {
            thread.join();
            running = false;
        } catch (InterruptedException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void run() {
        this.requestFocus();
        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000 / amountOfTicks;
        double delta = 0;

        long timer = System.currentTimeMillis();
        int frames = 0;

        while (running) {
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            while (delta >= 1) {
                tick();
                delta--;
            }
            if (running) {
                render();
                frames++;
            }
            if ((System.currentTimeMillis() - timer) > 1000) {
                timer += 1000;
                hud.FPS = frames;
                frames = 0;
            }
        }
        stop();
    }

    private void tick() {
        
        if(this.gameRun && player.health != 0 && !player.gameWin){
            handler.tick();
        }
        
        
    }

    private void render() {
        BufferStrategy bs = this.getBufferStrategy();
        if (bs == null) {
            this.createBufferStrategy(3);
            return;
        }

        Graphics g = bs.getDrawGraphics();
        g.setColor(new Color(135, 206, 235));
        g.fillRect(0, 0, WIDTH, HEIGHT);
        
        Graphics2D g2 = (Graphics2D) g;
        
        g2.translate(-camera.getX()/2, -camera.getY()/2);
        g.drawImage(bg1, -200, -250, this);
        g2.translate(-camera.getX()/2, -camera.getY()/2);
        
        if(player.health == 0) {
            this.handler.object.clear();
           
            g.setColor(Color.black);
            
            
            
           
        } else {
            handler.render(g);
        }

        
        g2.translate(camera.getX(), camera.getY());
        hud.render(g);
        
        if (gameState == STATE.GAME) {
            hud.render(g);
        }
        g.dispose();
        bs.show();
    }

    public static int clamp(int number, int min, int max) {
        if (number >= max) {
            return number = max;
        } else if (number <= min) {
            return number = min;
        }
        return number;
    }
}

package game;

import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class ImageLoader {

    private BufferedImage world;
    public static BufferedImage loadImage(String path, Object obj) {
        BufferedImage image = null;

        try {
            image = ImageIO.read(obj.getClass().getResource(path));
        } catch (Exception ex) {
            System.out.println("No world picture found !!" + path);
            System.exit(0);
        }
        return image;
    }
    public static void loadFileLevel(String path, Object obj, Handler handler, Player player){
        BufferedImage image = loadImage(path, obj);
        if(image != null)
            loadWorld(image, handler, player);
    }
    public static void loadWorld(BufferedImage image, Handler handler, Player player) {
        int w = image.getWidth();
        int h = image.getHeight();		

        for(int xx = 0; xx < w; xx++) {			
            for(int yy = 0; yy < h; yy++) {	
                
                int pixel = image.getRGB(xx, yy);
                int red = (pixel >>16) & 0x0ff;
                int green = (pixel >> 8) & 0x0ff;
                int blue = (pixel) & 0x0ff;

                
                if(red == 0 && green == 255 && blue == 33) {
                    handler.addObject(new Platform(xx*64, yy*64, ID.Platform));
                }else if(red == 255 && green == 216 & blue == 0) {
                    handler.addObject(new BlockingBox(xx*64, yy*64, ID.Platform));
                }else if(red == 255 && green == 0 & blue == 0) {
                    handler.addObject(new Fire(xx*64, yy*64, ID.Fire));
                }else if(red ==0 && green == 38 & blue == 255) {
                    handler.addObject(new Hyena(xx*64, yy*64, ID.Enemy));
                }else if(red ==64 && green == 64 & blue == 64) {
                    handler.addObject(new Ninja(xx*64, yy*64, ID.Enemy));
                }/*else if(red ==255 && green == 106 & blue == 0) {
                    handler.addObject(new MovingPlatform(xx*64, yy*64, ID.MovingPlatform));
                }*/else if(red ==0 && green == 148 & blue == 255) {
                    handler.addObject(new Bird(xx*64, yy*64, ID.Enemy));
                }else if(red ==160 && green == 160 & blue == 160) {
                    handler.addObject(new LevelDoor(xx*64, yy*64, ID.LevelDoor));
                }else if(red ==0 && green == 255 & blue == 255) {
                    handler.addObject(new Crystal(xx*64, yy*64, ID.Crystal));
                }else if(red ==178 && green == 0 & blue == 255) {
                    handler.addObject(new Diamond(xx*64, yy*64, ID.Trigger));
                }else if(red == 0 && green == 255 & blue == 0) {
                    player.setX(xx*64);
                    player.setY(yy*64);
                }
            }
        }
    }
}



package game;

import java.awt.Graphics;


public class BlockingBox extends GameObject {

    public BlockingBox(int x, int y, ID id) {
        super(x, y, id);
    }

    @Override
    public void tick() {

    }

    @Override
    public void render(Graphics g) {

    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author User
 */
public class MovingPlatform extends Platform {
    
    public MovingPlatform(int x, int y, ID id) {
        super(x, y, id);
        velX=1.5;
        width=150;
        height = 10;
    }
    public void tick(){
        
        x +=Math.round(velX);
    }
}



package game;


public class GameSpace {
    public static double gravity = 0.2;
    public static Game gameInstance = null;
}



package game;

import static game.Game.player;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;


public class HUD {
    Font font = new Font("Arial", Font.BOLD, 18);
    int FPS;
    public void render(Graphics g){
        g.setColor(Color.BLACK);
        g.setFont(font);
        g.drawString("FPS: "+ FPS, 50, 30);
        
        
        if (player.gameWin) {
            showGameWin(g);
        }
        if (player.health == 0){
            showGameOver(g);
           
        }
    }
    
    public void showGameOver(Graphics g) {
        g.setColor(new Color(0, 139, 139, 90));
        g.fill3DRect(250, 50, 500, 350, true);
        g.setColor(Color.black);
        g.drawString("Game Over ", 450, 250);
    }

    private void showGameWin(Graphics g) {
        g.setColor(new Color(0, 139, 139, 90));
        g.fill3DRect(250, 50, 500, 350, true);
        g.setColor(Color.black);
        g.drawString("Game Win", 450, 250);
    }
}


package game;

import static game.GameObject.BoundsType.DownBound;
import static game.GameObject.BoundsType.LeftBound;
import static game.GameObject.BoundsType.PlatformTrackerBound;
import static game.GameObject.BoundsType.RightBound;
import static game.GameObject.BoundsType.UpBound;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Hyena extends GameObject {
    boolean intersects = false;
    boolean onPlatform = false;
    int dist;
    int direction = 1;
    static BufferedImage idle[] = new BufferedImage[4];
    static BufferedImage walk[] = new BufferedImage[6];
    static BufferedImage attack[] = new BufferedImage[6];
    
    private final Animation hyenaIdle;
    private final Animation hyenaAttack;
    private final Animation hyenaWalk;

    public Hyena(int x, int y, ID id) {
        super(x, y, id, 64, 64);
        velX = 0;
        if(idle[0] == null){
            for(int i=0; i<4; i++){
                int index = i+1;
                idle[i] = ImageLoader.loadImage("res/Hyena_idle"+index+".png", this);
            }
        }
        hyenaIdle = new Animation(5, idle);
        
        if(walk[0] == null){
            for(int i=0; i<6; i++){
                int index = i+1;
                walk[i] = ImageLoader.loadImage("res/HyenaWalk"+index+".png", this);
            }
        }
        
        hyenaWalk = new Animation(6, walk);
        if(attack[0] == null){
            for(int i=0; i<6; i++){
                int index = i+1;
                attack[i] = ImageLoader.loadImage("res/HyenaAttack"+index+".png", this);
            }
        }
        hyenaAttack = new Animation(5, attack);
    }

    @Override
    public void tick() { 
        hyenaIdle.runAnimation();
        hyenaAttack.runAnimation();
        
        if(!onPlatform) {
            velY += GameSpace.gravity;
        }
        
        y += velY;
        
        
        int player_x = Game.player.x;
        dist = Math.abs(player_x-x);
        if(dist < 250){
            velX = 1;
            if(x + width<= player_x) {
                x += velX;
                direction = 0;
            }else if(this.x >= player_x+Game.player.width) {
                x -= this.velX;
                direction = 1;
            }
        }else
            velX = 0;
        
        Collision();
    }
     
    public void Collision() {
        intersects = false;
        onPlatform = false;
        for(int i = 0; i< Game.handler.object.size(); i++){
            GameObject obj = Game.handler.object.get(i);
            if( obj != this)
                if(obj.getId() == ID.Fire){
                    if(obj.getBounds().intersects(this.getBounds())){
                        Game.handler.removeObject(this);
                    }
                }
                if(obj.getId() == ID.Platform){
                    if(obj.getBounds().intersects(this.getBounds())){
                        if(obj.getBounds(DownBound).intersects(this.getBounds(UpBound))){
                            velY *=-1;
                            y = obj.getY()+obj.height + height;
                        }else if(obj.getBounds(LeftBound).intersects(this.getBounds(RightBound))){
                            velX *= -1;
                            x = obj.getX() - width;
                        }else if(obj.getBounds(RightBound).intersects(this.getBounds(LeftBound))){
                            velX *= -1;
                            x = obj.getX() + obj.width;
                        }else if(obj.getBounds(UpBound).intersects(this.getBounds(DownBound))){
                            velY = 0;
                            y = obj.getY()- height;
                        }
                    }
                    if(obj.getBounds().intersects(this.getBounds(PlatformTrackerBound))){
                        onPlatform = true;
                    }
                }
        }
    }
    
    @Override
    public void render(Graphics g) {
        int ind = 0;
        if(dist>64){
          
            if(velX == 0){
                if(direction != 0)
                    hyenaIdle.drawAnimation(g, x, y, width, height);
                else
                    hyenaIdle.drawAnimation(g, x+width, y, -width, height);
            }else{
                ind = Math.abs(((int)x/10)%5+1);
                if(direction != 0)
                    g.drawImage(walk[ind], x, y, width, height, null);
                else
                    g.drawImage(walk[ind], x+width, y, -width, height, null);
            }
        }else{
            if(direction != 0)
                hyenaAttack.drawAnimation(g, x, y, width, height);
            else
                hyenaAttack.drawAnimation(g, x+width, y, -width, height);

        }
    }
}


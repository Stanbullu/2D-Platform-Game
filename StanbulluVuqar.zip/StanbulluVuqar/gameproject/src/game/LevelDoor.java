

package game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Random;


public class LevelDoor extends GameObject {
    static BufferedImage image[] = new BufferedImage[2];
    protected boolean isOpen = false;
    
   
    public LevelDoor(int x, int y, ID id) {
        super(x, y-15, id, 40, 40);
        if(image[0] == null){
            image[0] = ImageLoader.loadImage("res/door1.png", this);
            image[1] = ImageLoader.loadImage("res/door2.png", this);
        }
    }

    @Override
    public void tick() {
        Collision();
    }
    
    public void Collision() {
        for(int i = 0; i< Game.handler.object.size(); i++){
            GameObject obj = Game.handler.object.get(i);
            if(obj.getId() == ID.Player){
                if(obj.getBounds().intersects(this.getBounds())){
                    if(Game.player.isDoorOpen)
                        isOpen = true;
                    else
                        isOpen = false;
                }
            }
        }
    }
    @Override
    public void render(Graphics g) { 
        if(isOpen){
            g.drawImage(image[1], x-20, y-20, 120, 120, null);
        }else{
            g.drawImage(image[0], x-20, y-20, 120, 120, null);
        }
    
    }
    
}



package game;

import static game.GameObject.BoundsType.DownBound;
import static game.GameObject.BoundsType.LeftBound;
import static game.GameObject.BoundsType.RightBound;
import static game.GameObject.BoundsType.UpBound;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;




public class Fire extends GameObject {
    
    static BufferedImage image;
    public String position;
    Timer timer = new Timer();
    
    public Fire(int x, int y, ID id) {
        super(x, y, id);
        if(image == null){
           
              image = ImageLoader.loadImage("res/fire.png", this);
            
        }
    }

    @Override
    public void tick() {

    }
    @Override
    public Rectangle getBounds(BoundsType type){
        switch(type){
            case UpBound: return new Rectangle (x+width/35,y+height/4,width-2*width/35,height/4);
            case DownBound: return new Rectangle (x+width/35,y+3*height/4,width-2*width/35, height/4);
            case LeftBound: return new Rectangle (x,y+height/6,width/4,height-height/4);
            case RightBound: return new Rectangle (x+width-width/6,y+height/6,width/6,height-height/3); 
            case PlatformTrackerBound: return new Rectangle (x+width/6,y+3*height/4,width-2*width/6,height/4+height/8);  
            default: return getBounds();
        }
    };
    @Override
    public void render(Graphics g) {
        g.drawImage(image, x, y, width, height, null);
        
    }
    
}
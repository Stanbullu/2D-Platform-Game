package game;

import static game.GameObject.BoundsType.DownBound;
import static game.GameObject.BoundsType.LeftBound;
import static game.GameObject.BoundsType.PlatformTrackerBound;
import static game.GameObject.BoundsType.RightBound;
import static game.GameObject.BoundsType.UpBound;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Player extends GameObject {

    boolean[] keyPressed = new boolean[5];
    public double speed = 0.3;
    public double maxSpeed = 4;
    public double jumpingSpeed = 1;
    Color col;
    int level = 1;
    public double health;
    boolean intersects = false;
    boolean onPlatform = false;
    int direction = 1;
    public boolean gameWin = false;
    public boolean isDoorOpen = false;

    static BufferedImage runImage[] = new BufferedImage[10];
    static BufferedImage stayImage[] = new BufferedImage[10];
    static BufferedImage jumpImage[] = new BufferedImage[10];
    static BufferedImage slideImage[] = new BufferedImage[10];

    public Player(int x, int y, ID id) {
        super(x, y, id, 64, 64);
        col = Color.blue;
        health = 100;
        friction = 0.2;

        if (stayImage[0] == null) {
            for (int k = 0; k < 10; k++) {
                stayImage[k] = ImageLoader.loadImage("res/Idle__00" + k + ".png", this);
            }
        }
        if (runImage[0] == null) {
            for (int i = 0; i < 10; i++) {
                runImage[i] = ImageLoader.loadImage("res/Run__00" + i + ".png", this);
            }
        }

        if (jumpImage[0] == null) {
            for (int j = 0; j < 10; j++) {
                jumpImage[j] = ImageLoader.loadImage("res/Jump__00" + j + ".png", this);

            }
        }
        if (jumpImage[0] == null) {
            for (int j = 0; j < 10; j++) {
                jumpImage[j] = ImageLoader.loadImage("res/Jump__00" + j + ".png", this);

            }
        }
    }

    @Override
    public void tick() {
        if (!onPlatform) {
            velY += GameSpace.gravity;
        } else {
            if (velX > 0.1 || velX < -0.1) {
                direction = (velX > 0) ? 1 : (velX < 0) ? 0 : direction;
                if (direction == 1) {
                    velX -= friction;
                } else {
                    velX += friction;
                }
            }
        }
        x += velX;
        y += velY;

        Controll();
        Collision();
    }

    public void Controll() {
        if (keyPressed[1]) {
            if (-1 * velX < maxSpeed) {
                velX -= speed;
            }
        }
        if (keyPressed[2]) {
            if (velX < maxSpeed) {
                velX += speed;
            }
        }
        if (keyPressed[3] && onPlatform) {
            velY -= jumpingSpeed;
        }
        if (keyPressed[4]) {
            velY += speed;
        }
    }

    public void Collision() {
        intersects = false;
        onPlatform = false;
        for (int i = 0; i < Game.handler.object.size(); i++) {
            GameObject obj = Game.handler.object.get(i);
            if (obj != this) {
                if (obj.getBounds().intersects(this.getBounds())) {
                    if (obj.getId() == ID.Enemy || obj.getId() == ID.Fire) {
                        health = (health > 0) ? health - 0.2 : 0;
                        intersects = true;
                    } else if (obj.getId() == ID.Trigger) {
                        Game.handler.removeObject(obj);
                        isDoorOpen = true;
                        i--;
                    } else if (obj.getId() == ID.Crystal) {
                        Game.handler.removeObject(obj);
                        i--;
                    } else if (obj.getId() == ID.Bullet) {
                        health = (health > 0) ? health - 1 : 0;
                        Game.handler.removeObject(obj);
                        i--;
                    }
                }
            }
            if (obj.getId() == ID.Platform) {
                if (obj.getBounds().intersects(this.getBounds())) {
                    if (obj.getBounds(DownBound).intersects(this.getBounds(UpBound))) {
                        velY *= -0.1;
                        y = obj.getY() + obj.height + height;
                    } else if (obj.getBounds(LeftBound).intersects(this.getBounds(RightBound))) {
                        velX *= -0.1;
                        x = obj.getX() - width;
                    } else if (obj.getBounds(RightBound).intersects(this.getBounds(LeftBound))) {
                        velX *= -0.1;
                        x = obj.getX() + obj.width;
                    } else if (obj.getBounds(UpBound).intersects(this.getBounds(DownBound))) {
                        velY = 0;
                        y = obj.getY() - height;
                    }
                }
                if (obj.getBounds().intersects(this.getBounds(PlatformTrackerBound))) {
                    onPlatform = true;
                }
            }
            if (obj.getBounds().intersects(this.getBounds())) {
                if (obj.getId() == ID.LevelDoor) {
                    Game g = GameSpace.gameInstance;
                    if (g != null) {
                        if (isDoorOpen) {
                            if (level == 1) {
                                gameWin = true;

                            }

                        }
                    }
                }
            }
            if (obj.getId() == ID.MovingPlatform) {
                if (obj.getBounds().intersects(this.getBounds())) {
                    if (obj.getBounds(DownBound).intersects(this.getBounds(UpBound))) {
                        velY *= -1;
                        y = obj.getY() + obj.height + height;
                    } else if (obj.getBounds(LeftBound).intersects(this.getBounds(RightBound))) {
                        velX *= -1;
                        x = obj.getX() - width;
                    } else if (obj.getBounds(RightBound).intersects(this.getBounds(LeftBound))) {
                        velX *= -1;
                        x = obj.getX() + obj.width;
                    } else if (obj.getBounds(UpBound).intersects(this.getBounds(DownBound))) {
                        velY = 0;
                        y = obj.getY() - height;
                    }
                }
                if (obj.getBounds().intersects(this.getBounds(PlatformTrackerBound))) {
                    onPlatform = true;
                    x += Math.round(obj.getVelX());
                }
                if (obj.getBounds().intersects(this.getBounds())) {
                    if (obj.getId() == ID.LevelDoor) {
                        Game g = GameSpace.gameInstance;
                        if (g != null) {
                            if (isDoorOpen == true) {
                                gameWin = true;

                            }
                        }
                    }
                }
            }
        }
    }

    public void CheckOnPlatform() {

    }

    @Override
    public void render(Graphics g) {

        int ind = 0;
        if (keyPressed[3]) {
            ind = Math.abs(((int) x / 15) % 9 + 1);
            if (direction == 1) {
                g.drawImage(jumpImage[ind], x, y, width, height, null);
            } else {
                g.drawImage(jumpImage[ind], x + width, y, -width, height, null);
            }
        } else if ((int) velX == 0) {
            ind = Math.abs(((int) x / 15) % 9 + 1);
            if (direction == 1) {
                g.drawImage(stayImage[ind], x, y, width, height, null);
            } else {
                g.drawImage(stayImage[ind], x + width, y, -width, height, null);
            }
        } else {
            ind = Math.abs(((int) x / 15) % 9 + 1);
            if (direction == 1) {
                g.drawImage(runImage[ind], x, y, width, height, null);
            } else {
                g.drawImage(runImage[ind], x + width, y, -width, height, null);
            }
        }

        g.setColor(Color.red);
        g.fill3DRect(x, y - 20, (int) (width), 8, true);

        g.setColor(Color.green);
        g.fill3DRect(x, y - 20, (int) (width * health / 100), 8, true);
    }
}

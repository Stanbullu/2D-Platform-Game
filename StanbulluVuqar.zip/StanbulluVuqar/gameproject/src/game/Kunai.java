
package game;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Kunai extends GameObject {
    private String position;
    private static BufferedImage image;
    private int firstLoc;
    
    public Kunai(int x, int y, ID id, String position) {
        super(x, y, id, 32, 32);
        velX = 5;
        this.position = position;
        
        if(image == null){
            image = ImageLoader.loadImage("res/Kunai.png", this);
        }
        
        this.firstLoc = x;
    }

    @Override
    public void tick() {
        if(Math.abs(x-firstLoc)<400){
            if(position == "right")
                x += velX;
            else if(position == "left")
                x -= velX;
        }else{
            Game.handler.removeObject(this);
        }
    }

    @Override
    public void render(Graphics g) {
        g.drawImage(image, x, y, width, height, null);
    }
    
}

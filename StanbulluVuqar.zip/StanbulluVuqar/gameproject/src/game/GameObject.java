
package game;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.io.Serializable;


public abstract class GameObject implements Serializable{
    protected int x , y;
    protected ID id;
    protected double velX , velY;
    protected int width = 64;
    protected int height = 64;
    protected double gravity = GameSpace.gravity;
    protected double friction = 0;
    protected enum BoundsType {
        General, 
        UpBound,
        DownBound,
        RightBound,
        LeftBound,
        PlatformTrackerBound
        
    };
            
    public GameObject(int x, int y, ID id) {
        this.x = x;
        this.y = y;
        this.id = id;
        this.width = 64;
        this.height = 64;
    }
    
    public GameObject(int x, int y, ID id, int width, int height) {
        this.x = x;
        this.y = y;
        this.id = id;
        this.width = width;
        this.height = height;
    }
    
    
    public ID getId() {
        return id;
    }

    public void setId(ID id) {
        this.id = id;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    
    
    public double getVelX() {
        return velX;
    }

    public double getVelY() {
        return velY;
    }
    
    
    
    public void  setVelX(int velX){
        this.velX = velX;
    }
    public void  setVelY(int velY){
        this.velY = velY;
    }
    
    
    public void setX(int x){
        this.x = x;
    }
    public void setY(int y){
        this.y = y;
    }
    public Rectangle getBounds(){
        return new Rectangle(x, y, width, height);
    };
    
    public Rectangle getBounds(BoundsType type){
        switch(type){
            case UpBound: return new Rectangle (x+width/6,y,width-2*width/6,height/4);
            case DownBound: return new Rectangle (x+width/6,y+3*height/4,width-2*width/6, height/4);
            case LeftBound: return new Rectangle (x,y+height/6,width/4,height-height/3);
            case RightBound: return new Rectangle (x+width-width/6,y+height/6,width/6,height-height/3); 
            case PlatformTrackerBound: return new Rectangle (x+width/6,y+3*height/4,width-2*width/6,height/4+height/8);  
            default: return getBounds();
        }
    };
    public abstract void tick();
    public abstract void render(Graphics g);
   
}
